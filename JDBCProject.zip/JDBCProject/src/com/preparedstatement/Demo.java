package com.preparedstatement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Demo {
	
	public static void main(String[] args) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/jdbc30sep?characterEncoding=latin1";
			Connection con=DriverManager.getConnection(url, "root", "root");
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter id>>");
			int id=sc.nextInt();//5
			System.out.println("Enter name>>");
			String name=sc.next();
			System.out.println("Enter salary>>");
			int salary=sc.nextInt();

			String query="insert into employee values (?,?,?)";
			//insert into employee values(id,name,salary)
			PreparedStatement pst=con.prepareStatement(query); //compile
			pst.setInt(1, id);//5 
			pst.setString(2,name);//Amar
			pst.setInt(3, salary);//9000
			//insert into employee values(5,'Amar',9000)
			
			
			int i=pst.executeUpdate();//run
			
			System.out.println(i+ " Row inserted successfully");
			con.close();
			pst.close();
			
		
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		
	}

}
