package com.statementinterface;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCDemo {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//step 1 : load the Driver class
		
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("step 1");
		
		//step 2: connection establish
		String url = "jdbc:mysql://localhost:3306/jdbc30sep?characterEncoding=latin1";
		Connection con=DriverManager.getConnection(url, "root", "root");
		System.out.println("step 2");
		//step 3: create the statement
		Statement st=con.createStatement();
		System.out.println("step 3");
		String query="insert into employee values (2,'Arti',15000)";
		//step 4: submit the sql statement
		int i=st.executeUpdate(query);//compile + run 
		//boolean result=st.execute(query);
		System.out.println(i+" row affected");
		con.close();
		st.close();
		
		
		
		
	}

}
