package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TelecomProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
