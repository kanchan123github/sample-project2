package com.example.entity;

public enum NetworkFunctionInstanceType {

	NRF, UDM, PCF
}
