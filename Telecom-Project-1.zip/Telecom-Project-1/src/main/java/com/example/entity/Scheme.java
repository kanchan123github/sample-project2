package com.example.entity;

public enum Scheme {

	http, https
}
