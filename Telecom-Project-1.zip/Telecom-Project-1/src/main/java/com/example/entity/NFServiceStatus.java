package com.example.entity;

public enum NFServiceStatus {

	Registered, Suspended, Undiscoverable
}
