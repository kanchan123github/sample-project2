package com.example.entity;

public enum NfStatus {

	Registered, NonRegistered
}
