package com.example.entity;

public enum NFServiceName {

	nnrf_nfm , nnrf_disc, nnrf_auth2
}
