package com.example.util;

public class MappingConstants {

	public static final String networkFunctionInstanceUri = "/networkFunctionInstance";
	public static final String nfProfileUri = "/nfProfile";
	public static final String nfServiceUri = "/nfService";
	
	public static final String save = "/save";


}
