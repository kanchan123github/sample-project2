package com.example.interceptors;

public class RecordNotFoundException extends RuntimeException {

}
