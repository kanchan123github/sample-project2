package com.project2;

public class Calculator extends Test {
	public static void main(String[] args) {

		System.out.println("Choose operator");
		int m = sc.nextInt();
		switch (m) {

		case 1:
			test1();
			System.out.println("the addition is>>" + add(a, b));
			break;
		case 2:
			test1();
			System.out.println("the subtraction is>>" + sub(a, b));
			break;
		case 3:
			test1();
			System.out.println("the multiplication is>>" + mul(a, b));
			break;
		case 4:
			test1();
			System.out.println("the division is>>" + div(a, b));
			break;
		case 5:
			test1();
			System.out.println("the modulus is>>" + mod(a, b));
			break;
		case 6:
			test2();
			System.out.println("the square is>>" + sqr(a));
			break;
		case 7:
			test2();
			System.out.println("the cube is>>" + cube(a));
			break;
		case 8:
			test3();
			System.out.println("the average is>>" + avg(a, b, c, d, e));
			break;
		case 9:
			test2();
			System.out.println("the factors are >>" + fact(a));
			break;
		default:
			System.out.println("invalid operator");

		}
	}

}
