package com.project2;

import java.util.*;

public class Test {
	static int a, b, c, d, e;
	static Scanner sc = new Scanner(System.in);

	static void test1() {
		System.out.println("Enter first number");
		a = sc.nextInt();
		System.out.println("Enter second number");
		b = sc.nextInt();

	}

	static void test2() {
		System.out.println("Enter a  number");
		a = sc.nextInt();
	}

	static void test3() {
		System.out.println("Enter first number");
		a = sc.nextInt();
		System.out.println("Enter second number");
		b = sc.nextInt();
		System.out.println("Enter third number");
		c = sc.nextInt();
		System.out.println("Enter fourth number");
		d = sc.nextInt();
		System.out.println("Enter fifth number");
		e = sc.nextInt();

	}

	static int add(int a, int b) {
		return a + b;
	}

	static int sub(int a, int b) {
		return a - b;
	}

	static int mul(int a, int b) {
		return a * b;
	}

	static int div(int a, int b) {
		return a / b;
	}

	static int mod(int a, int b) {
		return a % b;
	}

	static int sqr(int a) {
		return a * a;
	}

	static int cube(int a) {
		return a * a * a;
	}

	static int avg(int a, int b, int c, int d, int e) {
		return (a + b + c + d + e) / 5;
	}

	static int fact(int a) {
		int fact = 1;
		for (int i = 1; i <= a; i++) {
			fact = fact * i;
		}
		return fact;
	}

	static void evenodd(int a) {
		if (a > 0) {
			System.out.println("Even");
		} else {
			System.out.println("Odd");
		}

	}

}
